<div class="footer-container">
        <div style="font-size:50px; font-weight:200;" class="footer-logo jaro">Fuar Giyim</div>
        <div class="footer-description">Moda ve kalitenin buluşma noktası.</div>
        <ul class="footer-links">
            <li><a href="index.php">Ana Sayfa</a></li>
            <li><a href="urunler.php">Ürünlerimiz</a></li>
            <li><a href="iletisim.php">İletişime Geç</a></li>
            <li><a href="login.php">Giriş Yap</a></li>
            <li><a href="login.php?register">Kaydol</a></li>
        </ul>
        <p class="footer-text">&copy; 2024 Fuar Giyim. Tüm hakları saklıdır.</p>
    </div>
